## Platform support for fileSytem platform
## used as a wrapper for objects to be retrieved from the filesytem. Doesn't
## do much.
runPlatform.fileSystem <- function(module, inputs, modulePath) {
    
}
